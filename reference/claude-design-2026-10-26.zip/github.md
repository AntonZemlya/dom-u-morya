repo: AntonZemlya/dom-u-morya
branch: main

## Last sync
date: 2026-08-12T16:44:17Z

### Updated in this project
- Hero text moved to the right, overlay mirrored to keep the building visible on the left
- "О комплексе" panel: lighter/centered overlay, feature items styled as cards, tab-switch layout-shift fixed
- "Локация" given its own background for section separation
- Removed stray decorative glow blobs (left of "Локация" and "Застройщик")
- Divider/spacing cleanup between "Ход строительства" and "Застройщик"

## Screen map
| Screen | Repo files |
|---|---|
| Full landing page | index.html, styles.css, script.js, assets/ |

Note: this project's source of truth is `index.dc.html` (Design Component format). The repo holds a compiled plain HTML/CSS/JS static build — see `design_handoff_dom_u_morya/` for the handoff package used to update it via Claude Code.
