# CODING AGENTS: READ THIS FIRST

This is a handoff bundle from Claude Design (claude.ai/design). The user wants the updated design in this bundle pushed live to their existing GitHub repository.

## Target repository

- **Repo**: `AntonZemlya/dom-u-morya` (branch `main`)
- The repo already contains a working static build of this same site: `index.html`, `styles.css`, `script.js`, `favicon.png`, `assets/`.
- **Your job**: update that static build so it matches `project/index.dc.html` pixel-perfectly, then commit and push to `main`.

## About the design file

`project/index.dc.html` is a prototype built in an AI design tool (Design Components format — inline styles, a small templating runtime via `support.js`). It is **not** meant to be committed as-is. Read it top to bottom — it is the source of truth for the current design. Re-implement its markup, styles, and behavior (hero, stats bar, tabs in "О комплексе", location section, floor plans, pricing/mortgage calculator, construction progress, developer section, contact form, lightboxes, cookie banner) into the repo's existing plain HTML/CSS/JS structure, preserving that project's conventions (semantic HTML in `index.html`, styling in `styles.css`, behavior in `script.js`).

Fidelity: **high** — match colors, typography, spacing, and copy exactly as written in `project/index.dc.html`. Do not rewrite the Russian copy; carry it over verbatim.

## Recent changes to carry over (vs. the version currently live in the repo)

- Hero: text block moved to the right side and right-aligned (was left-aligned); overlay gradient mirrored to darken the right side instead of the left, so the building on the left of the photo reads clearly. On tablet/mobile the text reverts to left-aligned (the mobile overlay already darkens the full photo).
- "О комплексе" (About) section: the "Архитектура-маяк" photo panel — its dark overlay is now narrower/lighter and the text block is vertically centered instead of pinned to the bottom; the overlay width covers the text's full width so no text sits on unshaded sky.
- The four feature items under each "О комплексе" tab (Архитектура и виды / Двор и территория / Сервис в доме) are now styled as cards (`#FBFAF7` background, rounded, soft shadow) matching the card style used in "Ход строительства" / "Застройщик".
- Fixed a layout-shift bug: switching those tabs used to change the section's height (title/lead/card text lengths differ per tab). Reserved min-heights now keep the section height constant across all three tabs.
- "Локация" (Location) section now has its own background color (`#EEE8DC`) with a soft top fade, giving it clearer separation from "О комплексе" above and "Планировки" below (previously all three ran together on the same background).
- Removed a stray divider inside "Застройщик"; spacing between "Ход строительства" and "Застройщик" tightened.

## Assets

All images are in `project/assets/` (`.webp`) plus `project/favicon.png` — copy these into the repo's `assets/` as-is if not already present, or diff against what's already there.

## If anything is ambiguous

Ask the user to confirm before implementing — cheaper than guessing.

## Bundle contents

- `README.md` — this file
- `project/` — current design files: `index.dc.html` (source of truth), `support.js`, `assets/`, `favicon.png`
